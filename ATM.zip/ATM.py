import time

print("Please Enter Your Card Details")

time.sleep(5)

card_no = input("Enter Your CARD NUMBER (16 digits): ")
card_expdate = input("Enter Your CARD EXPIRY DATE (MM/YY): ")
card_ccv = input("Enter Your CVV NUMBER (3 digits): ")

print("Card details accepted. Processing...")

password = 1234

pin = int(input("Enter your ATM PIN: "))

balance = 5000

if pin == password:
    while True:
        print(""" 
            1 == Check Balance
            2 == Withdraw Balance
            3 == Deposit Balance
            4 == Exit
        """)

        try:    
            option = int(input("Enter your choice: "))
        except ValueError:
            print("Enter a valid option.")
            continue
        
        if option == 1:
            print(f"Your Current Balance is {balance}")
                                     
        elif option == 2:
            withdraw_amount = int(input("Enter Withdraw Amount: "))
            
            if withdraw_amount > balance:
                print("Insufficient funds.")
            else:
                balance -= withdraw_amount
                print(f"{withdraw_amount} is debited from your account")
                print(f"Your updated balance is {balance}")

        elif option == 3:
            deposit_amount = int(input("Enter Deposit Amount: "))
            balance += deposit_amount
            print(f"{deposit_amount} is credited to your account")
            print(f"Your Updated Balance is {balance}")

        elif option == 4:
            print("Thank you for using our ATM. Goodbye!")
            break

        else:
            print("Invalid choice. Please try again.")

else:
    print("WRONG PIN! Please try again...")